from django.apps import AppConfig


class ProfileConfig(AppConfig):
    name = '_profile'
