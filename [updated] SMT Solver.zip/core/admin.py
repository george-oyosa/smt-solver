from django.contrib import admin

from .models import Project, Task, Message, Upload

admin.site.register(Project)
admin.site.register(Task)
admin.site.register(Message)
admin.site.register(Upload)
