from django.urls import path, include
from core import views
urlpatterns = [
    path('dashboard/', views.dashboard, name="dashboard"),
    path('issue/', views.issueView, name="issue"),
    path('project/<int:id>', views.projectView, name="project"),
    path('seed/<int:id>', views.seedView, name="seed"),
    path('task/', views.taskView, name="task"),
    path("messages/", views.messages, name="messages"),
    path("message-customer/<int:task_id>/<int:customer_id>/", views.message_customer, name="message-customer"),
    path('assign/', views.assign),
    path('delete_task/', views.delete_task),
    path('delete_project/', views.delete_project),
    path('edit_project/', views.edit_project),
    path("search_dev/", views.search_dev),
    path("save_dev/", views.save_dev),
    path("remove_dev/", views.remove_dev),
    path("issue/public/<int:id>", views.publicissueView),
    path("message-customer/<int:id>/", views.publicissueView, name="message-customer"),
    path("upload/", views.upload_seed, name="upload"),
    path("debug/<int:user_id>/<int:seed_id>/", views.debug, name="debug"),


]
