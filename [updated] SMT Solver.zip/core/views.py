from email import message
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Project, Task, Message, Upload
from django.db.models import Q
from _auth.models import User
from _profile.models import Profile
from django.http import JsonResponse
from django.contrib.auth import logout
import subprocess

import os
import sys
import signal
import inspect
from pathlib import Path

path = Path(__file__)
rootpath = str(path.parent.absolute().parent)
sys.path.append(rootpath)

current_dir = os.getcwd()

from yinyang.src.base.Driver import run_checks
from yinyang.src.base.Error import raise_runtime_error
from yinyang.src.base.ArgumentParser import build_yinyang_parser
from yinyang.src.base.Exitcodes import OK_BUGS, OK_NOBUGS
from yinyang.src.base.Exitcodes import ERR_USAGE, ERR_INTERNAL

from yinyang.src.core.Fuzzer import Fuzzer

from yinyang.config.YinyangHelptext import (
    usage,
    header,
    short_description,
    long_description,
    options,
)


def solver():
    parser = build_yinyang_parser(current_dir, usage)
    args = run_checks(parser, "yinyang")
    try:
        fuzzer = Fuzzer(args, "yinyang")

        def print_stats():
            fuzzer.statistic.printsum()
            if fuzzer.statistic.crashes + fuzzer.statistic.soundness == 0:
                exit(OK_NOBUGS)
            exit(OK_BUGS)

        def stats_control_c(sig, frame):
            print("\b\b\rUser interrupt", flush=True)
            print_stats()
            if fuzzer.statistic.crashes + fuzzer.statistic.soundness == 0:
                exit(OK_NOBUGS)
            exit(OK_BUGS)

        def silent_control_c(sig, frame):
            if fuzzer.statistic.crashes + fuzzer.statistic.soundness == 0:
                exit(OK_NOBUGS)
            exit(OK_BUGS)

        if not args.quiet:
            signal.signal(signal.SIGINT, stats_control_c)
        else:
            signal.signal(signal.SIGINT, silent_control_c)
            exit(OK_NOBUGS)

        fuzzer.run()
        exit(OK_NOBUGS)
    except Exception as e:
        trace = inspect.trace()
        raise_runtime_error(trace, sys.argv, e)
        exit(ERR_INTERNAL)

def is_admin(user):
    return user.is_admin

def count_messages(request):
    user = request.user
    messages_count = 0
    if user.is_authenticated:
        messages_count = Message.objects.filter(Q(recepient=user) & Q(is_read=False)).count()
    return messages_count


@login_required
def dashboard(request):
    solver()

@login_required
def dashboard(request):
    user = request.user
    if request.method == "POST":
        title = request.POST.get('title')
        description = request.POST.get('description')
        project = Project(owner=request.user)
        project.title = title
        project.description = description
        project.save()
        project.dev.add(request.user)
        return redirect("project", id=project.id)
    if user.is_superuser or user.is_staff:
        projects = Project.objects.filter( Q(owner=request.user) | Q(dev__in=[request.user])
        ).distinct()
    else:
        projects = Project.objects.filter(task__created_by=user)
    uploads = Upload.objects.values('creator').distinct()
    if not user.is_superuser:
        uploads = Upload.objects.filter(creator=user).values('creator').distinct()
    creators = User.objects.filter(id__in=uploads)

    context = {
        'projects': projects, 
        'task_count': count_task(request),
        'messages_count': count_messages(request),
        'user': user,
        'creators': creators,
    }
    return render(request, 'core/dashboard.html', context)


def projectView(request, id):
    try:
        project = Project.objects.get(id=id)
    except:
        project = None

    if request.method == "POST":
        title = request.POST.get('title')
        description = request.POST.get('description')
        project.title = title
        project.description = description
        project.save()
    return render(request, 'core/project.html', {
        "project": project, 
        'task_count': count_task(request),
        'messages_count': count_messages(request),
        })

def seedView(request, id):
    creator = User.objects.get(id=id)
    try:
        seeds = Upload.objects.filter(creator=creator)
    except:
        seeds = None
    all_staff = User.objects.filter(is_staff=True)
    commands = ['python3', './yinyang/bin/yinyang', '"z3"', '-o', 'sat', '-s', 'fusion', f'"uploads/{creator.username}/"']
    command = ' '.join(commands)

    if request.method == "POST":
        staff = request.POST.get('staff', None)
        command = request.POST.get('command', None)
        if staff:
            staff = User.objects.get(id=staff)
            for seed in seeds:
                seed.staff = staff
                seed.save()
        if command:
            try:
                report = subprocess.run(command, shell=True, stdout=subprocess.PIPE, text=True).stdout.splitlines() #.decode('utf-8')
            except:
                creator = User.objects.get(id=creator.id)
                commands = ['python3', './yinyang/bin/yinyang', '"z3"', '-o', 'sat', '-s', 'fusion', f'"uploads/{creator.username}/"']
                command = ' '.join(commands)
                report = subprocess.run(command, shell=True, stdout=subprocess.PIPE, text=True).stdout.splitlines() #.decode('utf-8')
            errors = report[-1]

            return render(request, 'core/report.html', {
                'seeds': ', '.join([seed.name for seed in seeds]),
                'files': ', '.join([seed.get_name for seed in seeds]),
                'seed': seeds.first(),
                'report': report,
                'tasks_count': count_task(request),
                'command': command,
                "creator": creator,
            })
    return render(request, 'core/seed.html', {
        "seeds": seeds, 
        "creator": creator,
        'task_count': count_task(request),
        'messages_count': count_messages(request),
        'all_staff': all_staff,
        'command': command,
        'cwd': os.getcwd(),
        })


@login_required
@csrf_exempt
def assign(request):
    if request.method == "POST":
        id = request.POST.get('id')
        username = request.POST.get('username')
        try:
            user = User.objects.get(username=username)
            task = Task.objects.get(id=id)
            project = Project.objects.get(task__in=[task])
            if request.user == project.owner or request.user == user:
                task.dev = user
                task.assigned = True
                task.save()
                project.save()
                cout_update(project, assigend=True)
                return JsonResponse({'status': 200})
            raise ValueError

        except:
            return JsonResponse({'status': 403})


@login_required
@csrf_exempt
def delete_task(request):
    if request.method == "POST":
        try:
            id = request.POST.get('id')
            task = Task.objects.get(id=id)
            project = task.project
            if request.user == project.owner:
                task.delete()
                project.bugs = project.bugs - 1
                project.save()
                return JsonResponse({'status': 200})
            return JsonResponse({'status': 403})
        except:
            return JsonResponse({'status': 403})


@login_required
@csrf_exempt
def delete_project(request):
    if request.method == "POST":
        try:
            id = request.POST.get('id')
            project = Project.objects.get(id=id)
            if request.user == project.owner:
                project.delete()
                return JsonResponse({'status': 200})
            return JsonResponse({'status': 400})
        except:
            return JsonResponse({'status': 400})


@login_required
@csrf_exempt
def edit_project(request):
    if request.method == "POST":
        try:
            id = request.POST.get('id')
            title = request.POST.get('title')
            description = request.POST.get('description')
            project = Project.objects.get(id=id)
            if request.user == project.owner:
                project.title = title
                project.description = description
                project.save()
                return JsonResponse({'status': 200})
            return JsonResponse({'status': 403})
        except:
            return JsonResponse({'status': 400})


@login_required
@csrf_exempt
def search_dev(request):
    if request.method == "POST":
        try:
            # if True:
            email = request.POST.get('email')
            user = User.objects.get(
                Q(email=email) | Q(username=email)
            )
            profile = Profile.objects.get(user=user)
            return JsonResponse({'name': profile.name, 'github': profile.github, 'username': user.username, 'status': 200})
        except:
            return JsonResponse({'status': 400})


@login_required
@csrf_exempt
def save_dev(request):
    if request.method == "POST":
        # try:
        if True:
            project_id = request.POST.get('project_id')
            dev_username = request.POST.get('dev_username')

            user = User.objects.get(username=dev_username)
            project = Project.objects.get(id=project_id)
            if project.owner == request.user:
                if user in project.dev.all():
                    return JsonResponse({'status': 403})
                project.dev.add(user)
                return JsonResponse({'user_id': user.id, 'status': 200})
            raise ValueError
        # except:
        #     return JsonResponse({'status': 400})


@login_required
@csrf_exempt
def remove_dev(request):
    if request.method == "POST":
        project_id = request.POST.get('project_id')
        dev_id = request.POST.get('dev_id')

        try:
            user = User.objects.get(id=dev_id)
            project = Project.objects.get(id=project_id)
            if project.owner == request.user:
                project.dev.remove(user)
                return JsonResponse({'status': 200})
            raise ValueError
        except:
            return JsonResponse({'status': 400})


@login_required
@csrf_exempt
def issueView(request):
    if request.method == "POST":
        project_id = request.POST.get("project_id")
        title = request.POST.get("title")
        reproduce = request.POST.get("reproduce")
        environment = request.POST.get("environment")
        comment = request.POST.get("comment")

        project = Project.objects.get(id=project_id)
        task = Task()
        task.title = title
        task.reproduce = reproduce
        task.environment = environment
        task.comment = comment
        task.project = project
        task.created_by = request.user
        task.save()
        project.task.add(task)
        cout_update(project, bug=True)
        return JsonResponse({"status": 200})

    # projects = Project.objects.filter(
    #     Q(owner=request.user) | Q(dev__in=[request.user])
    # ).distinct()
    projects = Project.objects.distinct()
    return render(request, 'core/bug-issue.html', {
        'task_count': count_task(request), 
        'projects': projects,
        'messages_count': count_messages(request),
        })


@csrf_exempt
def publicissueView(request, id):
    project = get_object_or_404(Project, id=id)
    if request.method == "POST":
        try:
            email = request.POST.get("email")
            title = request.POST.get("title")
            reproduce = request.POST.get("reproduce")
            environment = request.POST.get("environment")
            comment = request.POST.get("comment")

            task = Task()
            task.title = title
            task.reproduce = reproduce
            task.environment = environment
            task.comment = comment
            task.project = project
            task.email = email
            task.save()
            project.task.add(task)
            cout_update(project, bug=True)
            return JsonResponse({"status": 200})
        except:
            return JsonResponse({"status": 400})

    return render(request, 'core/bug-issue-public.html', {
        "project": project, 
        'task_count': count_task(request),
        'messages_count': count_messages(request),
        })


@csrf_exempt
@login_required
def taskView(request):
    tasks = Task.objects.filter(dev=request.user)
    profile, _ = Profile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        task_id = request.POST.get('task_id')
        solution = request.POST.get('solution')
        task = Task.objects.get(id=task_id)
        task.solution = solution
        task.assigned = False
        task.done = True
        task.save()
        profile.fixed = profile.fixed + 1
        profile.save()
        cout_update(task.project, fixed=True)
        return JsonResponse({"status": 200})

    return render(request, 'core/task.html', {
        "tasks": tasks, 
        'task_count': count_task(request), 
        'messages_count': count_messages(request),
        "fixed_task": profile.fixed
        })


def count_task(request):
    if request.user.is_authenticated:
        tasks = Task.objects.filter(Q(dev=request.user), Q(done=False))
        return tasks.count()
    return None


def cout_update(project, bug=False, assigend=False, fixed=False):
    if bug:
        project.bugs = project.bugs+1
    elif assigend:
        project.bugs = project.bugs - 1
        project.assigned = project.assigned + 1
    elif fixed:
        project.assigned = project.assigned - 1
        project.fixed = project.fixed + 1
    project.save()

@csrf_exempt
@login_required
def message_customer(request, task_id, customer_id):
    customer = User.objects.get(id=customer_id)
    task = Task.objects.get(id=task_id)
    if request.method == 'POST':
        message = request.POST.get('message', None)
        message = Message.objects.create(
            recepient=customer,
            body=message,
            task=task
        )
        message.save()
    return render(request, 'core/create-message.html', {
        'customer': customer,
        'task': task,
    })

@login_required
def messages(request):
    user = request.user
    messages = Message.objects.filter(recepient=user)
    messages.update(is_read=True)
    messages_count = messages.count()
    return render(request, 'core/messages.html', {
        'messages': messages,
        'messages_count': count_messages(request),
        'task_count': count_task(request),
    })

@login_required
def upload_seed(request):
    user = request.user
    if request.method == 'POST':
        seeds = request.FILES.getlist('seeds')
        name = request.POST.get('name')
        try:
            for seed in seeds:
                Upload.objects.create(creator=user, seed=seed, name=name)
        except:
            return redirect('upload')
    return redirect('dashboard')

@login_required
def debug(request, user_id, seed_id):
    seed = Upload.objects.get(id=user_id)
    creator = User.objects.get(id=user_id)
    commands = ['python3', './yinyang/bin/yinyang', '"z3"', '-o', 'sat', '-s', 'fusion', f'"uploads/{creator.username}/"']
    command = ' '.join(commands)

    report = subprocess.run(command, shell=True, stdout=subprocess.PIPE, text=True).stdout.splitlines() #.decode('utf-8')
    errors = report[-1]
    print(f"\nLine: {errors}\n")

    return render(request, 'core/report.html', {
        'seed': seed,
        'report': report,
        'user_id': user_id,
        'tasks_count': count_task(request),
        'command': command,
    })