from django.contrib import admin
from .models import Code

admin.site.register(Code)
